def decrypt_cryptogram(ciphered_quote, shift_key):
    """Decrypts a cryptogram using a given shift key.

    Args:
        ciphered_quote: The input ciphered quote.
        shift_key: The shift key to use for decryption.

    Returns:
        The decrypted quote.
    """

    decrypted_quote = ""

    for char in ciphered_quote:
        if char.isalpha():
            decrypted_char = chr((ord(char) - ord('A') - shift_key) % 26 + ord('A'))
            decrypted_quote += decrypted_char
        else:
            decrypted_quote += char

    return decrypted_quote

def find_shift_key(ciphered_quote, known_quote):
    """Finds the shift key used to encrypt a given ciphered quote.

    Args:
        ciphered_quote: The input ciphered quote.
        known_quote: The known decrypted quote.

    Returns:
        The shift key used for encryption, or None if no valid shift key is found.
    """

    for shift_key in range(26):
        decrypted_quote = decrypt_cryptogram(ciphered_quote, shift_key)
        if decrypted_quote == known_quote:
            return shift_key

    # If no valid shift key is found, return None
    return None

if __name__ == "__main__":
    ciphered_quote = "VZ FRYSVFU VZCNGVRAG NAQ N YVGGYR VAFRPHER V ZNXR ZVFGNXRF V NZ BHG BS PBAGEBY NAQNG GVZRF UNEQ GB UNAQYR OHG VS LBH PNAG UNAQYR ZR NG ZL JBEFG GURA LBH FHER NF URYYQBAG QRFREIR ZR NG ZL ORFG ZNEVYLA ZBAEBR"
    known_quote = "THIS IS A SECRET MESSAGE THAT NO ONE WILL BE ABLE TO DECODE"

    shift_key = find_shift_key(ciphered_quote, known_quote)
    print("Shift key:", shift_key)

    if shift_key is not None:
        decrypted_quote = decrypt_cryptogram(ciphered_quote, shift_key)
        print("Decrypted quote:", decrypted_quote)
    else:
        print("No valid shift key found.")