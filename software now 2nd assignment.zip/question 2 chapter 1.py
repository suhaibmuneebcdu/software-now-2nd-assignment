import time
from PIL import Image 

# Load the image
image = Image.open("chapter1.jpg")
width, height = image.size

# Create a new image with the same size
new_image = Image.new("RGB", (width, height))

# Generate the number (already provided in the prompt)
current_time = int(time.time())

generated_number = (current_time % 100) + 50
if generated_number % 2 == 0:
    generated_number += 10
    print(generated_number)
    
# Iterate through each pixel and modify its values
for x in range(width):
    for y in range(height):
        r, g, b = image.getpixel((x, y))
        new_r = r + generated_number
        new_g = g + generated_number
        new_b = b + generated_number
        new_image.putpixel((x, y), (new_r, new_g, new_b))

# Save the new image
new_image.save("chapterlout.png")

# Calculate the sum of red pixel values
red_sum = 0
for x in range(width):
    for y in range(height):
        r, _, _ = new_image.getpixel((x, y))
        red_sum += r

# Print the sum
print("Sum of red pixel values:", red_sum)