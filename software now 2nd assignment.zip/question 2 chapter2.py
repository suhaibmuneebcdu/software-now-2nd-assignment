def separate_string(s):
    """Separates a string into two substrings: one containing only numbers and the other containing only letters.

    Args:
        s: The input string.

    Returns:
        A tuple containing the two substrings.
    """

    number_substring = ""
    letter_substring = ""

    for char in s:
        if char.isdigit():
            number_substring += char
        else:
            letter_substring += char

    return number_substring, letter_substring

def convert_to_ascii(substring, char_type):
    """Converts the even numbers in a number substring or the upper-case letters in a letter substring to their ASCII code decimal values.

    Args:
        substring: The input substring.
        char_type: Either 'number' or 'letter', indicating the type of characters to convert.

    Returns:
        A list of ASCII code decimal values.
    """

    ascii_codes = []

    for char in substring:
        if (char_type == 'number' and int(char) % 2 == 0) or (char_type == 'letter' and char.isupper()):
            ascii_codes.append(ord(char))

    return ascii_codes

if __name__ == "__main__":
    s = "561984sktr235270aYmn145ss785fsq3100"

    number_substring, letter_substring = separate_string(s)
    print("Number substring:", number_substring)
    print("Letter substring:", letter_substring)

    number_ascii_codes = convert_to_ascii(number_substring, 'number')
    print("ASCII code decimal values for even numbers:", number_ascii_codes)

    letter_ascii_codes = convert_to_ascii(letter_substring, 'letter')
    print("ASCII code decimal values for upper-case letters:", letter_ascii_codes)