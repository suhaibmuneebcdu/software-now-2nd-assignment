def encrypt(text, key):
    """Encrypts a given text using a Caesar cipher with the specified key.

    Args:
        text: The text to be encrypted.
        key: The shift key for the encryption.

    Returns:
        The encrypted text.
    """

    encrypted_text = ""

    for char in text:
        if char.isalpha():
            shifted = ord(char) + key
            if char.islower():
                if shifted > ord('z'):
                    shifted -= 26
                elif shifted < ord('a'):
                    shifted += 26
            elif char.isupper():
                if shifted > ord('Z'):
                    shifted -= 26
                elif shifted < ord('A'):
                    shifted += 26
            encrypted_text += chr(shifted)
        else:
            encrypted_text += char

    return encrypted_text

def decrypt(encrypted_text, key):
    """Decrypts a given encrypted text using a Caesar cipher with the specified key.

    Args:
        encrypted_text: The encrypted text to be decrypted.
        key: The shift key for the decryption.

    Returns:
        The decrypted text.
    """

    return encrypt(encrypted_text, -key)  # Decryption is the same as encryption with a negative key

if __name__ == "__main__":
    original_code = "this is a secret message that no one will be able to decode"
    key = 15

    encrypted_code = encrypt(original_code, key)
    print("Encrypted code:", encrypted_code)

    decrypted_code = decrypt(encrypted_code, key)
    print("Decrypted code:", decrypted_code)